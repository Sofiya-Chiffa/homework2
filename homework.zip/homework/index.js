import express from "express";
import { open } from "sqlite";
import sqlite3 from "sqlite3";

async function openDB() {
  return open({
    filename: "sqlite.db",
    driver: sqlite3.Database
  });
}

async function init() {
  const db = await openDB();
  const app = express();
  const port = 3000;

  app.get("/getList", async (req, res) => {
    const message = req.query.message;
    const offset = req.query?.offset || 0;
    const limit = req.query?.limit || 9999;
    const sort = req.query?.sort || "asc";
    const result = await db.all(
      "SELECT * FROM comments ORDER BY date " + sort + " LIMIT " + offset + ", " + limit,
     
    );
    res.send(result);
  });

  app.get("/addItem", async (req, res) => {
    const message = req.query.message;
    const date = new Date();

    const obj = {
        date: date.getTime(),
        message: message,
    };

    const result = await db.run(
      "INSERT INTO comments (date, message) VALUES (:date, :message)",
      {
        ":date": obj.date,
        ":message": obj.message,
      }
    );
    res.send(result);
  });

  app.get("/deleteItem", async (req, res) => {
    const id = req.query.id;
    const result = await db.run(
      "DELETE FROM comments WHERE ID=:ID", 
      {
        ":ID": id,
      }
      );
      res.send(result);
  });

  app.listen(port);
}

init();
